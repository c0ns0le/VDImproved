/**
 * 
 */
package src;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

import length.Length;
/**
 * @author Matt
 *
 */
public class Lab4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		ArrayList <Length> lengths = new ArrayList<Lenght>();
		Scanner in = null;
		try {
		    in = new Scanner(new File("data.txt"));
		} catch (FileNotFoundException exception) {
		    throw new RuntimeException("failed to open data.txt");
		}
		// need more code for other parts of this assignment
		while (in.hasNext()) {
		   if( in.hasNextDouble())
			    Length length = in;
		   if(in.hasNextString())
			   String unit = in.next();
		
		    // code here to use the value of unit to create the
		    // right type of Length object and store it in length.
		    System.out.println(length);
		    // need more code for other parts of this assignment
		}
		// need more code for other parts of this assignment
	}

}
