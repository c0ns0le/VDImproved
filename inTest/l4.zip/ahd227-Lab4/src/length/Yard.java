/**
 * 
 */
package length;

/**
 * @author Matt
 *
 */
public class Yard extends Length {

	/**
	 * @param length
	 */
	public Yard(double length) {
		super(length);
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see length.Length#add(length.Length)
	 */
	@Override
	public void add(Length other) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see length.Length#getUnit()
	 */
	@Override
	public String getUnit() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see length.Length#toMeters()
	 */
	@Override
	public double toMeters() {
		// TODO Auto-generated method stub
		return 0;
	}

}
